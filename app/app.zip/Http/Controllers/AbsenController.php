<?php

namespace App\Http\Controllers;

use App\Models\Absen;
use App\Models\Karyawan;
use App\Models\Status;
use Illuminate\Http\Request;

class AbsenController extends Controller
{
    public function index(Request $r)
    {
        $data = [
            'title' => 'Absensi',
            'absen' => Absen::join('karyawans', 'tb_absen.id_karyawan', 'karyawans.id')->get(),
            'karyawan' => Karyawan::all(),
            'status' => Status::all(),
        ];
        return view('absen.absen', $data);
    }

    public function tambahAbsen(Request $r)
    {
        // dd($r->id_karyawan);
        Absen::create([
            'id_karyawan' => $r->id_karyawan,
            'status' => $r->status,
            'tgl' => $r->tgl,
            'id_lokasi' => $r->id_lokasi,
        ]);
        return redirect()->route('absen')->with('success', 'Berhasil tambah absen');
    }

    public function editAbsen(Request $r)
    {
        Absen::where('id_absen', $r->id_absen)->update(['status' => $r->status]);
        return redirect()->route('absen')->with('success', 'Berhasil edit absen');
    }

    public function hapusAbsen(Request $r)
    {
        Absen::where('id_absen', $r->id_absen)->delete();
        return redirect()->route('absen')->with('error', 'Berhasil hapus status');
    }
}
