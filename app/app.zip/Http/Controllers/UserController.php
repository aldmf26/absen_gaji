<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index(Request $r)
    {
        $data = [
            'title' => 'Data User',
            'user' => User::all()
        ];
        return view('user.user',$data);
    }

    public function tambahUser(Request $r)
    {
        User::create([
            'name' => $r->name,
            'username' => $r->username,
            'password' => bcrypt($r->password),
        ]);
        return redirect()->route('user')->with('success', 'Berhasil tambah user');
    }

    public function hapusUser(Request $r)
    {
        User::where('id',$r->id)->delete();
        return redirect()->route('user')->with('error', 'Berhasil hapus user');
    }
}
