<?php

namespace App\Http\Controllers;

use App\Models\Karyawan;
use Illuminate\Http\Request;

class KaryawanController extends Controller
{

    public function index()
    {
        $data = [
            'title' => 'Data Karyawan',
            'karyawan' => Karyawan::orderBy('id', 'desc')->get(),
        ];
        return view('karyawan.karyawan', $data);
    }

    
    public function tambahKaryawan(Request $r)
    {

        $data = [
            'nm_karyawan' => $r->nm_karyawan,
            'tgl_masuk' => $r->tgl_masuk,
            'posisi' => $r->posisi,
        ];
        Karyawan::create($data);
        return redirect()->route('karyawan')->with('success', 'Berhasil tambah karyawan');
    }

    public function editKaryawan(Request $r)
    {
        $data = [
            'nm_karyawan' => $r->nm_karyawan,
            'tgl_masuk' => $r->tgl_masuk,
            'posisi' => $r->posisi,
        ];
        Karyawan::where('id',$r->id)->update($data);
        return redirect()->route('karyawan')->with('success', 'Berhasil edit karyawan');
    }

    public function hapusKaryawan(Request $r)
    {
        Karyawan::where('id', $r->id)->delete();
        return redirect()->route('karyawan')->with('error', 'Berhasil hapus karyawan');
    }
}
