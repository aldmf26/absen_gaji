<div id="footer-tanggal">
    Banjarmasin, <?php echo tgl_indo(date('Y-m-d')); ?>
</div>
<div id="footer-jabatan">
    Kepala Koperasi
</div>
<style>
    .ttd {
        position: absolute;
        margin-left: 860px;
        margin-top: -120px;
    }
</style>
<div class="ttd">
    <img width="500" height="140" src="{{ asset('upload/ttd2.png') }}" alt="">
</div>
<div id="footer-nama">
    Aftahuddin
</div>
</div>
</body>

</html><!-- Akhir halaman HTML yang akan di konvert -->
<script>
    // window.print()
</script>
