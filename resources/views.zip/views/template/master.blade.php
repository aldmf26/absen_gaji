
@include('template.head')

    @include('template.sidebar')

        @include('template.header')
            @yield('content')
                

            </div>
            <!-- End of Main Content -->

        

 @include('template.footer')