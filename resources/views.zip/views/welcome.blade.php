@extends('template.master')
@section('content')
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h3><i class="fa fa-home"></i> Home </h3>
        </div>

        <!-- Content Row -->
        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Koperasi Harum Manis Bersatu</h1>
                <p>
                    Jl. Belitung Darat Rt.07 No.11
                    Kec. Banjarmasin Barat, Prov. Kalimantan Selatan. HP : 0511-4413552
                </p>
            </div>
            {{-- <div class="card">
                <div class="card-body">
                    <h5>KOPERASI ADALAH</h5>
                </div>
            </div> --}}

        </div>

        <!-- Content Row -->

        <div class="row">

        </div>

        <!-- Content Row -->
        <div class="row">
        </div>

    </div>
@endsection

<!-- /.container-fluid -->
